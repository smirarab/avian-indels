shortname-intronic-locus-indel-files (3679 files)

-- files ARE named "locus_chr1_8_uce.indels.phy"
		
The taxon names used in these files are the five character abbreviations used in the
Jarvis et al. analyses:

STRCA	Struthio_camelus
TINMA	Tinamus_guttatus
ANAPL	Anas_platyrhynchos
MELGA	Meleagris_gallopavo
GALGA	Gallus_gallus
PHORU	Phoenicopterus_ruber
PODCR	Podiceps_cristatus
COLLI	Columba_livia
MESUN	Mesitornis_unicolor
PTEGU	Pterocles_gutturalis
CUCCA	Cuculus_canorus
TAUER	Tauraco_erythrolophus
CHLUN	Chlamydotis_macqueenii
CHAVO	Charadrius_vociferus
BALRE	Balearica_regulorum_gibbericeps
OPHHO	Opisthocomus_hoazin
CAPCA	Antrostomus_carolinensis
CHAPE	Chaetura_pelagica
CALAN	Calypte_anna
GAVST	Gavia_stellata
FULGL	Fulmarus_glacialis
APTFO	Aptenodytes_forsteri
PYGAD	Pygoscelis_adeliae
PHALE	Phaethon_lepturus
NIPNI	Nipponia_nippon
EGRGA	Egretta_garzetta
PELCR	Pelecanus_crispus
PHACA	Phalacrocorax_carbo
EURHE	Eurypyga_helias
CATAU	Cathartes_aura
HALAL	Haliaeetus_albicilla
HALLE	Haliaeetus_leucocephalus
TYTAL	Tyto_alba
COLST	Colius_striatus
LEPDI	Leptosomus_discolor
APAVI	Apaloderma_vittatum
BUCRH	Buceros_rhinoceros_silvestris
MERNU	Merops_nubicus
PICPU	Picoides_pubescens
CARCR	Cariama_cristata
FALPE	Falco_peregrinus
NESNO	Nestor_notabilis
MELUN	Melopsittacus_undulatus
ACACH	Acanthisitta_chloris
CORBR	Corvus_brachyrhynchos
MANVI	Manacus_vitellinus
GEOFO	Geospiza_fortis
TAEGU	Taeniopygia_guttata
